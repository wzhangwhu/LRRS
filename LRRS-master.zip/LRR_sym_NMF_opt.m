function Z = LRR_sym_NMF_opt(X, Z_ini, H_ini, lambda1, lambda2, max_iter, Ctg)
% This is part of main code
[m,n] = size(X);
% ---------- Initilization -------- %
miu = 0.01;
rho = 1.2;
max_miu = 1e8;
tol  = 1e-5;
C1 = zeros(m,n);
C2 = zeros(n,n);
C3 = zeros(n,n);
C4 = zeros(n,n);
E = zeros(m,n);

for iter = 1:max_iter
    if iter == 1
        Z = Z_ini;
        H = H_ini;
        S = Z_ini;
        U = Z_ini;
        clear Z_ini
    end

    % -------- Update Z --------- %
    Z = Ctg*(X'*(X-E+C1/miu)+S+U-(C2+C3)/miu);
    Z = Z - diag(diag(Z));

    % -------- Update S --------- %
    distH = L2_distance_1(H, H);
    dist = distH;
    S = Z + (C2-dist)/miu;
    S = S - diag(diag(S));
    for ic = 1:n
        idx = 1:n;
        idx(ic) = [];
        S(ic,idx) = EProjSimplex_new(S(ic, idx));          %
    end

    % ----------Update H----------- %
    S1 = (abs(Z)+abs(Z'))/2;
    L = diag(sum(S)) - S;
    H(H == 0) = 1e-6;
    H(isnan(H)) = 1e-6;
    H = H.*(2*lambda2*(S1+S1')*H+miu*H)./(2*lambda2*H+(L+L')*H+H*(C4+C4'));

    % -------- Update U --------- %
    temp = Z + C3/miu;
    temp(isnan(temp)) = 0;
    temp((temp==inf)) = 0;
    temp((temp==-inf)) = 0;

    [AU, SU, VU] = svd(temp, 'econ');
    AU(isnan(AU)) = 0;
    VU(isnan(VU)) = 0;
    SU(isnan(SU)) = 0;
    SU = diag(SU);
    SVP = length(find(SU>1/miu));
    if SVP >= 1
        SU = SU(1:SVP) - 1/miu;
    else
        SVP = 1;
        SU = 0;
    end
    U = AU(:,1:SVP)*diag(SU)*VU(:,1:SVP)';

    % ------- Update E ---------- %
    temp1 = X - X*Z + C1/miu;
    temp2 = lambda1/miu;
    E = solve_l1l2(temp1, temp2); % L21 norm

    % -------- Update C1 C2 C3 C4 miu -------- %
    L1 = X - X*Z - E;
    L2 = Z - S;
    L3 = Z - U;
    L4 = H'*H - eye(size(H, 2));
    C1 = C1 + miu*L1;
    C2 = C2 + miu*L2;
    C3 = C3 + miu*L3;
    C4 = C4 + miu*L4;
    LL = norm(Z-U,'fro');
    miu = min(rho*miu, max_miu);

    % --------- obj ---------- %
    stop = LL;
    if stop < tol || iter == max_iter
        fprintf('The number of iterations for LRRS to reach convergence: %d\n', iter)
        break;
    end
end

end


function [E] = solve_l1l2(W,lambda)
n = size(W,2);
E = W;
for i=1:n
    E(:,i) = solve_l2(W(:,i),lambda);
end
end

function [x] = solve_l2(w,lambda)
% min lambda |x|_2 + |x-w|_2^2
nw = norm(w);
if nw>lambda
    x = (nw-lambda)*w/nw;
else
    x = zeros(length(w),1);
end
end

%% 
% If you find the code is useful, please cite the following reference:
%Joint low rank representation with symmetric orthogonal decomposition for clustering of
% scRNA-seq data

%%
close all
clear
clc
clear memory;
currentFolder = pwd; % add the current folder into the path
addpath(genpath(currentFolder))
addpath(fullfile(pwd, 'data'));
addpath(fullfile(pwd, 'function'));

%%
 dataset = {'Kolod', 'Ting', 'Li_islet', 'Zheng'}
% dataset = {'Ting'}

for ii = 1:length(dataset)
    ii
    load(dataset{ii});
    fea = in_X;% cellnum*genenum
    gnd = true_labs(:);
    selected_class = length(unique(gnd));
    lambda1 = 10;
    lambda2 = 10;
    fea = double(fea);
    nnClass = length(unique(gnd));
    select_sample = [];
    select_gnd = [];
    for i = 1:selected_class
        idx = find(gnd == i);
        idx_sample = fea(idx, :);
        select_sample = [select_sample; idx_sample];
        select_gnd = [select_gnd; gnd(idx)];
    end
    fea = select_sample';
    fea = fea./repmat(sqrt(sum(fea.^2)), [size(fea,1) 1]);
    gnd = select_gnd;
    X = fea;
    clear fea select_gnd select_sample idx
    tic()
    % ---------- initilization for Z and F -------- %
    options = [];
    options.NeighborMode = 'KNN';
    options.k = floor(log2(size(X,2))) + 1;
    options.WeightMode = 'Cosine';
    Z = constructW(X', options); % initial of Z = R^n*n, representation matrix
    [ng, nc] = size(X); % ng--number of genes; nc--number of cells
    S1 = (abs(Z)+abs(Z'))/2;
    H_ini = Symmetric_H_opt_revise(S1, 200);
    Z_ini = Z;
    clear Z

    max_iter = 40;
    Ctg = inv(X'*X+2*eye(size(X,2)));
    Z = LRR_sym_NMF_opt(X, Z_ini, H_ini, lambda1, lambda2, max_iter, Ctg); % X=XZ+E, Z = R^n*n, representation graph
    similarity = (abs(Z)+abs(Z'))/2;
    [result_label, kerNS] = SpectralClustering(similarity, nnClass);
    NMI(ii) = Cal_NMI_newused(gnd, result_label);
    ARI(ii) = Contingency_ARI_newused(gnd, result_label);
    ACC(ii) = ACC_ClusteringMeasure(gnd, result_label);
    Time(ii) = toc()
    fprintf(['NMI_for_ ' dataset{ii} ' is %f\n'], NMI(ii))
    fprintf(['ARI_for_ ' dataset{ii} ' is %f\n'], ARI(ii))
    fprintf(['ACC_for_ ' dataset{ii} ' is %f\n'], ACC(ii))

end


function [groups, kerNS] = SpectralClustering(CKSym,n)
%--------------------------------------------------------------------------
% This function takes an adjacency matrix of a graph and computes the
% clustering of the nodes using the spectral clustering algorithm of
% Ng, Jordan and Weiss.
% CMat: NxN adjacency matrix
% n: number of groups for clustering
% groups: N-dimensional vector containing the memberships of the N points
% to the n groups obtained by spectral clustering
%--------------------------------------------------------------------------
% Copyright @ Ehsan Elhamifar, 2012
% Modified @ Chong You, 2015
%--------------------------------------------------------------------------
warning off;
N = size(CKSym,1);
% Normalized spectral clustering according to Ng & Jordan & Weiss
% using Normalized Symmetric Laplacian L = I - D^{-1/2} W D^{-1/2}
DN = diag(1./sqrt(sum(CKSym)+eps) );   %eps=2.2204e-16
LapN = speye(N) - DN * CKSym * DN;  % speye(N)����N*N�Խ�Ԫ��Ϊ1�ľ���  ����������˹����
LapN(isnan(LapN))=0;
LapN(find(LapN==inf))=0;
LapN(find(LapN==-inf))=0;
[~,~,vN] = svd(LapN); %% ����ֵ�ֽ�
kerN = vN(:,N-n+1:N);
%kerN = vN(:,N-12:N);
normN = sum(kerN .^2, 2) .^.5;%% normalize the matrix U by L2-Norm
kerNS = bsxfun(@rdivide, kerN, normN + eps);  %% ����kerN ÿһ�г���normN+eps
%-------------
%Y = pdist(kerNS);
%Z = linkage(Y);
%groups = cluster(Z,'maxclust',n);
MAXiter = 1000; % Maximum number of iterations for KMeans
REPlic = 100; % Number of replications for KMeans
groups = kmeans(kerNS,n,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');  %% ����kmeans����
end

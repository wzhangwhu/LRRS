function H = Symmetric_H_opt_revise(S,max_iter)
%  S=HH', H'H=I  , S:n*n  H:n*n

[m,n] = size(S);
mu = 0.1; % 

rho = 1.2;
max_miu = 1e8;
tol  = 1e-5;
H = rand(n,n);
%  constraint H'*H = I
[Q, ~] = qr(H);
H_ini = Q;
% initialize Y1
Y1 = zeros(n,n);

% iteration process
for iter = 1:max_iter
    if iter == 1
        H = H_ini;
        clear H_ini
    end
    H_old = H;
    %  update
    term1 = (4 + 2 * mu) * (H * H') * H;
    term2 = 0.5 * H * (Y1 + Y1');
    term3 = 4 * S * H + mu * H;
    
    % 
    epsilon = 1e-8;
    denominator = term3 + epsilon * eye(size(term3));
    % update H
    H = (term1 + term2) / denominator;
    %  H'*H = I
    [Q, ~] = qr(H);
    H = Q;
    % update Y1
    Y1 = Y1 + mu * (H' * H - eye(m));
    
    LL1 = norm(H-H_old,'fro');
    
    SLSL =max(max(LL1));
    if mu*SLSL < tol
        mu = min(rho*mu,max_miu);
    end
    % --------- obj ---------- %
    stopC =max(abs(Y1(:)));
    if stopC < tol
        break;
    end
end
